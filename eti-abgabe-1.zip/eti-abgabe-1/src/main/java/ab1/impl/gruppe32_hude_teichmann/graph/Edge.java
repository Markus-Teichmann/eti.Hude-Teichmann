package ab1.impl.gruppe32_hude_teichmann.graph;

public interface Edge {
    public Vertex getStartVertex();
    public Character getTransition();
    public Vertex getEndVertex();
}
