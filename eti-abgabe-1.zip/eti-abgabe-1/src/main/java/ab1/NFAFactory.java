package ab1;

public interface NFAFactory {
    NFA buildNFA(String startState);
}
